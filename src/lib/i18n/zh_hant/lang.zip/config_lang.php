<?php

return [
    "en",
    "zh_hans",
    "zh_hant"

];
