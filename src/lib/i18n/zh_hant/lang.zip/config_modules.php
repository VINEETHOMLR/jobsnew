<?php 
return [
    'Dashboard',
    'promo',
    'multi_languages',
];